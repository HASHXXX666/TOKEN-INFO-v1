@echo off
REM Installer les modules nécessaires
pip install colorama pystyle --quiet

REM Exécuter le script Python
python TOKEN-INFO.py
pause
