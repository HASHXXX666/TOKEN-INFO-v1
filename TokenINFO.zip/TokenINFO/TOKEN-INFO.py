import os
import json
import colorama
from pystyle import Colorate, Colors
import subprocess
import webbrowser
import sys

def open_discord_invite():
    invite_url = "https://discord.gg/MuvSx2vxXu"
    webbrowser.open(invite_url)

if __name__ == "__main__":
    open_discord_invite()

   
    print("Configuration valide.")

def main():
    # Affiche l'interface ASCII art
    print(colored_ascii_art)

if __name__ == "__main__":

    
    # colorama
    colorama.init()

    # couleur
    color =  "033[95m"

    # Définit l'interface ASCII art
    interface = f"""
▄▄▄█████▓ ▒█████   ██ ▄█▀▓█████  ███▄    █     ██▓ ███▄    █   █████▒▒█████  
▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓█   ▀  ██ ▀█   █    ▓██▒ ██ ▀█   █ ▓██   ▒▒██▒  ██▒
▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒███   ▓██  ▀█ ██▒   ▒██▒▓██  ▀█ ██▒▒████ ░▒██░  ██▒
░ ▓██▓ ░ ▒██   ██░▓██ █▄ ▒▓█  ▄ ▓██▒  ▐▌██▒   ░██░▓██▒  ▐▌██▒░▓█▒  ░▒██   ██░
  ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░▒████▒▒██░   ▓██░   ░██░▒██░   ▓██░░▒█░   ░ ████▓▒░
  ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒░   ▒ ▒    ░▓  ░ ▒░   ▒ ▒  ▒ ░   ░ ▒░▒░▒░ 
    ░      ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░░ ░░   ░ ▒░    ▒ ░░ ░░   ░ ▒░ ░       ░ ▒ ▒░ 
  ░      ░ ░ ░ ▒  ░ ░░ ░    ░      ░   ░ ░     ▒ ░   ░   ░ ░  ░ ░   ░ ░ ░ ▒  
             ░ ░  ░  ░      ░  ░         ░     ░           ░            ░ ░  
                                                                             

                                   [MADE BY HASH_XXX]

                               [      Discord Tools      ]  
                                  1. Token   Information  
                                  2. Token   Checker         
                                  3. Token   Dmall                
                                  4. Token   Raid                 
                                  5. Token   Name                 
                                  6. Token   Hypesquad            
                                  7. Token   Bio                                     
                                  8. Webhook Info                                    
                                  9. Webhook Spammer                            
                                  10. Tool info                              
                                                            
"""

    colored_ascii_art = Colorate.Horizontal(Colors.purple_to_blue, interface)
    main()

while True:
    os.system('cls')  # Utiliser 'clear' pour Linux/Mac
    print(colored_ascii_art)
    
    gg = input("""
┌──(user@advanced)-[~/Home]
│                      
└─$> """)
    
    if gg.isdigit():
        gg = int(gg)
    
        if gg == 1:
            subprocess.run(['python', 'plugins\\Discord\\Tokeninfo.py'])
        elif gg == 2:
            subprocess.run(['python', 'plugins\\Discord\\Tokenchecker.py'])
        elif gg == 3:
            subprocess.run(['python', 'plugins\\Discord\\Tokendmall.py'])
        elif gg == 4:
            subprocess.run(['python', 'plugins\\Discord\\Tokenraid.py'])
        elif gg == 5:
            subprocess.run(['python', 'plugins\\Discord\\Tokenname.py'])
        elif gg == 6:
            subprocess.run(['python', 'plugins\\Discord\\Tokenhypesquad.py'])
        elif gg == 7:
            subprocess.run(['python', 'plugins\\Discord\\Tokenbio.py'])
        elif gg == 8:
            subprocess.run(['python', 'plugins\\Discord\\Webhookinfo.py'])
        elif gg == 9:
            subprocess.run(['python', 'plugins\\Discord\\Webhookspammer.py'])
        elif gg == 10:
            subprocess.run(['python', 'plugins\\Discord\\info.py'])
        else:
            print("\033[95mVeuillez entrer un numéro valide.")
            input("\033[95mAppuyez sur Entrée pour continuer...")