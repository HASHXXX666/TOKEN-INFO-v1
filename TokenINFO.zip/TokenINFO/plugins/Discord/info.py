# tools_catalogue.py
import os
import time
from pystyle import Colorate, Colors

# --- Configuration d'affichage ---
DELAY_LINE = 0.02
DELAY_CARD = 0.01
GRADIENT = Colors.purple_to_blue

def clear():
    os.system('cls' if os.name == 'nt' else 'clear')

def slow_print(text, line_delay=DELAY_LINE, end_delay=0.0):
    """Affiche un bloc de texte ligne par ligne avec dégradé."""
    for line in text.splitlines():
        print(Colorate.Horizontal(GRADIENT, line))
        time.sleep(line_delay)
    if end_delay:
        time.sleep(end_delay)

def small_pause():
    time.sleep(DELAY_CARD)

# --- Contenu des fiches ---
TOOLS = {
    "1": {
        "title": "Token Information",
        "status": "✅ safe",
        "description": "Récupère des informations publiques liées à un token (profil, ID, avatar si accessible).",
        "note": "Utiliser uniquement pour vos propres tokens ou avec autorisation explicite.",
        "alternatives": "- Utiliser l'API officielle d'un bot pour récupérer des infos de manière conforme."
    },
    "2": {
        "title": "Token Checker",
        "status": "✅/⚠️ risky",
        "description": "Vérifie si un token est valide (réponse du serveur).",
        "note": "Outil légitime pour vérifier ses propres tokens ; l'utilisation sur tokens tiers peut être abusive.",
        "alternatives": "- Faire des vérifications locales ou via un bot autorisé, respecter les règles d'usage."
    },
    "3": {
        "title": "Token Dmall",
        "status": "⚠️ risky",
        "description": "Envoie un message direct (DM) au nom du compte lié au token.",
        "note": "Peut être utilisé pour contact légitime, mais également pour spam/harcèlement. Usage restreint.",
        "alternatives": "- Utiliser un bot officiel avec permissions et respecter le consentement des destinataires."
    },
    "4": {
        "title": "Token Raid",
        "status": "❌ refused",
        "description": "Actions de masse automatiques (raid) visant à perturber ou harceler.",
        "note": "Fonctionnalité dangereuse et abusive — assistance refusée.",
        "alternatives": "- Aucune alternative dangereuse fournie. Pour modération légitime, créez des outils d'administration conformes."
    },
    "5": {
        "title": "Token Name",
        "status": "✅/⚠️ risky",
        "description": "Change le nom d'utilisateur associé au token.",
        "note": "Opération administrative sur votre compte ; ne pas effectuer sur comptes tiers.",
        "alternatives": "- Utiliser l'interface officielle Discord ou un bot autorisé pour gérer les changements acceptés."
    },
    "6": {
        "title": "Token Hypesquad",
        "status": "⚠️ risky",
        "description": "Modifie le badge HypeSquad du compte (house selection).",
        "note": "Peut ne pas fonctionner pour tous les comptes et doit rester dans un cadre autorisé.",
        "alternatives": "- Gérer via les options officielles du compte ou contacter le support si besoin."
    },
    "7": {
        "title": "Token Bio",
        "status": "✅/⚠️ risky",
        "description": "Modifie la biographie (bio) du compte.",
        "note": "Légitime pour votre compte. Ne pas modifier la bio d'utilisateurs sans consentement.",
        "alternatives": "- Utiliser l'interface utilisateur officielle ou un bot autorisé."
    },
    "8": {
        "title": "Webhook Info",
        "status": "✅ safe",
        "description": "Récupère les informations publiques d'un webhook (id, nom, avatar, channel, guild).",
        "note": "Permet de diagnostiquer un webhook que vous administrez ; n'expose pas d'accès secret.",
        "alternatives": "- Consultez la documentation Discord sur les webhooks pour usages conformes."
    },
    "9": {
        "title": "Webhook Spammer",
        "status": "❌ refused",
        "description": "Envoi massif de messages vers un webhook (spamming).",
        "note": "Fonctionnalité abusive — assistance refusée.",
        "alternatives": "- Pour tests, utiliser un environnement de test local ou un webhook de test en mode simulation (dry‑run)."
    },
    "10": {
        "title": "Tool info",
        "status": "✅ safe",
        "description": "Page d'information et d'aide listant les outils disponibles, leur statut et alternatives légales.",
        "note": "Utile pour la documentation et le support d'utilisation responsable.",
        "alternatives": "- Générer un README ou documentation markdown standardisée."
    }
}

# --- Fonctions d'affichage des cartes ---
def render_header():
    header = """
                                   [MADE BY HASH_XXX]

                               [      Discord Tools      ]
"""
    slow_print(header, line_delay=0.01)

def render_menu():
    lines = [
        "1.  Token Information        — Récupère des infos publiques sur un token.",
        "2.  Token Checker            — Vérifie si un token est valide.",
        "3.  Token Dmall              — Envoie un message direct (DM) — ⚠️ usage abusif possible.",
        "4.  Token Raid               — Actions de masse (raid) — ❌ refusé / dangereux.",
        "5.  Token Name               — Change le nom d'utilisateur lié au token.",
        "6.  Token Hypesquad          — Change le badge HypeSquad du compte.",
        "7.  Token Bio                — Modifie la bio du compte.",
        "8.  Webhook Info             — Récupère les informations publiques d'un webhook.",
        "9.  Webhook Spammer          — Envoi massif vers webhook — ❌ refusé / dangereux.",
        "10. Tool info                — Page d'information / aide sur l'outil.",
        "",
        "Tape le numéro pour afficher la fiche détaillée, ou 'q' pour quitter."
    ]
    slow_print("\n".join(lines), line_delay=0.01)

def show_card(key):
    tool = TOOLS.get(key)
    if not tool:
        print(Colorate.Horizontal(GRADIENT, "[!] Entrée invalide."))
        return
    clear()
    render_header()
    title_block = f"""
=== {tool['title']} ===
Statut   : {tool['status']}

Description :
{tool['description']}

Note :
{tool['note']}

Alternatives / recommandations :
{tool['alternatives']}
"""
    slow_print(title_block, line_delay=0.01)
    small_pause()
    input(Colorate.Horizontal(GRADIENT, "\nAppuyez sur Entrée pour revenir au menu..."))
    clear()
    render_header()
    render_menu()

# --- Main loop ---
def main():
    clear()
    render_header()
    render_menu()
    while True:
        choice = input(Colorate.Horizontal(GRADIENT, "\nChoix -> ")).strip().lower()
        if choice in ("q", "quit", "exit"):
            slow_print("\nMerci — restez dans un usage responsable et légal.", line_delay=0.02)
            break
        if choice == "":
            continue
        if choice not in TOOLS:
            print(Colorate.Horizontal(GRADIENT, "[!] Numéro inconnu. Réessaie."))
            continue
        # Affiche la fiche (safe, texte seulement)
        show_card(choice)

if __name__ == "__main__":
    main()
