import requests
import json
import time
from pystyle import Colors, Colorate
import os

os.system('cls')

# Fonction pour afficher le texte lentement
def print_text_slowly(text, delay=0.05):
    lines = text.splitlines()
    for line in lines:
        print(Colorate.Horizontal(Colors.purple_to_blue, line))
        time.sleep(delay)
    print()

# ASCII Art remplacé par [MADE BY HASH_XXX]
ascii_art = """
▄▄▄█████▓ ▒█████   ██ ▄█▀▓█████  ███▄    █     ██▓ ███▄    █   █████▒▒█████  
▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓█   ▀  ██ ▀█   █    ▓██▒ ██ ▀█   █ ▓██   ▒▒██▒  ██▒
▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒███   ▓██  ▀█ ██▒   ▒██▒▓██  ▀█ ██▒▒████ ░▒██░  ██▒
░ ▓██▓ ░ ▒██   ██░▓██ █▄ ▒▓█  ▄ ▓██▒  ▐▌██▒   ░██░▓██▒  ▐▌██▒░▓█▒  ░▒██   ██░
  ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░▒████▒▒██░   ▓██░   ░██░▒██░   ▓██░░▒█░   ░ ████▓▒░
  ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒░   ▒ ▒    ░▓  ░ ▒░   ▒ ▒  ▒ ░   ░ ▒░▒░▒░ 
    ░      ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░░ ░░   ░ ▒░    ▒ ░░ ░░   ░ ▒░ ░       ░ ▒ ▒░ 
  ░      ░ ░ ░ ▒  ░ ░░ ░    ░      ░   ░ ░     ▒ ░   ░   ░ ░  ░ ░   ░ ░ ░ ▒  
             ░ ░  ░  ░      ░  ░         ░     ░           ░            ░ ░  

                                  [MADE BY HASH_XXX]
"""

def change_username(token, new_username):
    url = 'https://discord.com/api/v9/users/@me'
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json',
    }
    data = {
        'username': new_username
    }

    try:
        response = requests.patch(url, headers=headers, data=json.dumps(data))
        response.raise_for_status()
        print_text_slowly(f"Nom d'utilisateur changé en {new_username}")
    except requests.exceptions.HTTPError as err:
        print_text_slowly(f"Erreur lors du changement du nom d'utilisateur -> {err}")
    except Exception as e:
        print_text_slowly(f"Erreur : {e}")

if __name__ == "__main__":
    print_text_slowly(ascii_art)

    token = input(Colorate.Horizontal(Colors.purple_to_blue, "Entrez le token du compte Discord -> "))
    new_username = input(Colorate.Horizontal(Colors.purple_to_blue, "Entrez le nouveau nom d'utilisateur -> "))

    change_username(token, new_username)
