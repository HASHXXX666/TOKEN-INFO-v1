import os
import json
import requests
import time
import threading
from pystyle import Colorate, Colors

ascii_art = """
▄▄▄█████▓ ▒█████   ██ ▄█▀▓█████  ███▄    █     ██▓ ███▄    █   █████▒▒█████  
▓  ██▒ ▓▒▒██▒  ██▒ ██▄█▒ ▓█   ▀  ██ ▀█   █    ▓██▒ ██ ▀█   █ ▓██   ▒▒██▒  ██▒
▒ ▓██░ ▒░▒██░  ██▒▓███▄░ ▒███   ▓██  ▀█ ██▒   ▒██▒▓██  ▀█ ██▒▒████ ░▒██░  ██▒
░ ▓██▓ ░ ▒██   ██░▓██ █▄ ▒▓█  ▄ ▓██▒  ▐▌██▒   ░██░▓██▒  ▐▌██▒░▓█▒  ░▒██   ██░
  ▒██▒ ░ ░ ████▓▒░▒██▒ █▄░▒████▒▒██░   ▓██░   ░██░▒██░   ▓██░░▒█░   ░ ████▓▒░
  ▒ ░░   ░ ▒░▒░▒░ ▒ ▒▒ ▓▒░░ ▒░ ░░ ▒░   ▒ ▒    ░▓  ░ ▒░   ▒ ▒  ▒ ░   ░ ▒░▒░▒░ 
    ░      ░ ▒ ▒░ ░ ░▒ ▒░ ░ ░  ░░ ░░   ░ ▒░    ▒ ░░ ░░   ░ ▒░ ░       ░ ▒ ▒░ 
  ░      ░ ░ ░ ▒  ░ ░░ ░    ░      ░   ░ ░     ▒ ░   ░   ░ ░  ░ ░   ░ ░ ░ ▒  
             ░ ░  ░  ░      ░  ░         ░     ░           ░            ░ ░  

                                  [MADE BY HASH_XXX]
"""

def print_text_slowly(text, delay=0.05):
    lines = text.splitlines()
    for line in lines:
        print(Colorate.Horizontal(Colors.purple_to_blue, line))
        time.sleep(delay)
    print()

def get_dm_channel_ids(token_discord):
    try:
        response = requests.get("https://discord.com/api/v9/users/@me/channels", headers={'Authorization': token_discord})
        if response.status_code == 200:
            channels = response.json()
            return [channel['id'] for channel in channels if channel['type'] == 1]
        else:
            print(Colorate.Horizontal(Colors.purple_to_blue, f"[ERROR] Status code {response.status_code}: Unable to fetch DM channels."))
            return []
    except Exception as e:
        print(Colorate.Horizontal(Colors.purple_to_blue, f"[ERROR] Error fetching DM channel IDs: {e}"))
        return []

def save_ids_to_json(dm_channel_ids, filename):
    with open(filename, 'w') as f:
        json.dump(dm_channel_ids, f, indent=4)

def MassDM(token_discord, dm_channel_ids, message):
    try:
        for channel_id in dm_channel_ids:
            response = requests.post(f"https://discord.com/api/v9/channels/{channel_id}/messages",
                                     headers={'Authorization': token_discord, 'Content-Type': 'application/json'},
                                     json={"content": message})
            if response.status_code == 200:
                print(Colorate.Horizontal(Colors.purple_to_blue, f"[INFO] Message sent to channel ID: {channel_id}"))
            else:
                print(Colorate.Horizontal(Colors.purple_to_blue, f"[ERROR] Status code {response.status_code}: Unable to send message to channel ID: {channel_id}"))
    except Exception as e:
        print(Colorate.Horizontal(Colors.purple_to_blue, f"[ERROR] Error sending message: {e}"))

if __name__ == "__main__":
    try:
        os.system('cls')  # 'clear' pour Linux/Mac
        print_text_slowly(ascii_art)

        token_discord = input(Colorate.Horizontal(Colors.purple_to_blue, "Entrez le token -> ")).strip()
        message = input(Colorate.Horizontal(Colors.purple_to_blue, "Entrez le message -> ")).strip()
        output_file = "dm_channel_ids.json"

        dm_channel_ids = get_dm_channel_ids(token_discord)
        if not dm_channel_ids:
            print(Colorate.Horizontal(Colors.purple_to_blue, "[INFO] Aucun ID de DM collecté. Fermeture."))
            exit(0)

        save_ids_to_json(dm_channel_ids, output_file)
        print(Colorate.Horizontal(Colors.purple_to_blue, f"[INFO] Tous les DM IDs sauvegardés dans {output_file}."))
        print(Colorate.Horizontal(Colors.purple_to_blue, f"[INFO] Total DM channel IDs collectés: {len(dm_channel_ids)}"))

        proceed = input(Colorate.Horizontal(Colors.purple_to_blue, "Voulez-vous envoyer le message à tous les DM collectés ? (y/n) ")).strip().lower()
        if proceed == 'y':
            for channel_id in dm_channel_ids:
                t = threading.Thread(target=MassDM, args=(token_discord, [channel_id], message))
                t.start()
                t.join()
                print(Colorate.Horizontal(Colors.purple_to_blue, f"[INFO] Messages envoyés au channel {channel_id}."))
        else:
            print(Colorate.Horizontal(Colors.purple_to_blue, "Fermeture sans envoi de messages."))

    except Exception as e:
        print(Colorate.Horizontal(Colors.purple_to_blue, f"[ERROR] {e}"))
